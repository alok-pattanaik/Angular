import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  // name = "";
  // age = 0;

  myArr = {
    name: "",
    age: 0
  }

  arr = [
    {
      name: "ABC",
      age: 15
    },
    {
      name: "DEF",
      age: 18
    }
  ];

  constructor() { }

  ngOnInit(): void {
  }

  submit(myform) {
    this.arr.push(myform.form.value);
  }

}
